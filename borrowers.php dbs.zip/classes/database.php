<?php

class database{


    function opencon(): PDO{
        return new PDO(
    dsn: 'mysql:host=localhost;
    dbname=dbs_app',
    username: 'root',
    password: ''); 

    }

    function insertUser($email, $password_hash, $is_active){
        $con = $this->opencon();

        try{
            $con->beginTransaction();
            $stmt = $con->prepare('INSERT INTO Users (username,user_password_hash,is_active) VALUES (?,?,?)');
            $stmt->execute([$email, $password_hash, $is_active]);
            $user_id = $con->lastInsertId();
            $con->commit();
            return $user_id;

        }catch(PDOException $e){  
            if($con->inTransaction()){
                $con->rollBack();
            }
            throw $e;
        }
    }
    function insertBorrower($firstname, $lastname,$email,$phone,$member_since,$is_active){ 
        $con = $this->opencon();

        try{
            $con->beginTransaction();
            $stmt = $con->prepare('INSERT INTO Borrowers (borrower_firstname,borrower_lastname,borrower_email,borrower_phone_number,borrower_member_since,is_active) VALUES (?,?,?,?,?,?)');
            $stmt->execute([$firstname, $lastname,$email,$phone,$member_since,$is_active]);
            $borrower_id = $con->lastInsertId();
            $con->commit();
            return $borrower_id;

        }catch(PDOException $e){
            if($con->inTransaction()){
                $con->rollBack();
            }
            throw $e;
        }

    }

    function insertBorrowerUser($user_id, $borrower_id){
        $con = $this->opencon();
    
        try{
            $con->beginTransaction();
            $stmt = $con->prepare('INSERT INTO BorrowerUser (user_id, borrower_id) VALUES (?,?)');
            $stmt->execute([$user_id, $borrower_id]);
            $bu_id = $con->lastInsertId();
            $con->commit();
            return true;
            
        }catch(PDOException $e){
            if($con->inTransaction()){
                $con->rollBack();
            }
            throw $e;
        }
    }

    function viewBorrowerUser(){
        $con = $this->opencon();
        return $con->query("SELECT * from Borrowers")->fetchAll();
    }

    function insertBorrowerAddress($borrower_id,$house_number,$street,$barangay,$city,$province,$postal_code,$is_primary){
        $con = $this->opencon();

        try{
            $con->beginTransaction();
            $stmt = $con->prepare('INSERT INTO BorrowerAddress (borrower_id,ba_house_number,ba_street,ba_barangay,ba_city,ba_province,ba_postal_code,is_primary) VALUES (?,?,?,?,?,?,?,?)');
            $stmt->execute([$borrower_id,$house_number,$street,$barangay,$city,$province,$postal_code,$is_primary]);
            $borrower_id = $con->lastInsertId();
            $con->commit();
            return $borrower_id;

        }catch(PDOException $e){  
            if($con->inTransaction()){
                $con->rollBack();
            }
            throw $e;
        }
    }

}